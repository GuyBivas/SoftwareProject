#pragma once
void RunGame(int *heapSizes, int n);
void PrintState(int *heapSizes, int n, int turn);